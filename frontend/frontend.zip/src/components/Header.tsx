import { useAuth } from '@/store/auth'
import { useNavigate } from 'react-router-dom'
import { Input, Badge, Avatar, Dropdown } from 'antd'
import { SearchOutlined, BellOutlined, UserOutlined, SettingOutlined, LogoutOutlined, MenuOutlined } from '@ant-design/icons'

export default function Header() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const onLogout = () => {
    logout()
    navigate('/login')
  }

  const toggleMobileSidebar = () => {
    const overlay = document.getElementById('mobile-sidebar-overlay')
    if (overlay) {
      overlay.style.display = overlay.style.display === 'none' ? 'block' : 'none'
    }
  }

  const userMenuItems = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: 'Profil',
    },
    {
      key: 'settings',
      icon: <SettingOutlined />,
      label: 'Ayarlar',
      onClick: () => navigate('/settings'),
    },
    {
      type: 'divider' as const,
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Çıkış Yap',
      onClick: onLogout,
    },
  ]

  return (
    <header className="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-4 lg:px-6 shadow-sm">
      {/* Mobile menu button */}
      <button
        onClick={toggleMobileSidebar}
        className="lg:hidden p-2 rounded-lg hover:bg-gray-50 transition-colors duration-200"
      >
        <MenuOutlined className="text-gray-600 text-lg" />
      </button>

      <div className="flex items-center flex-1 max-w-md lg:ml-0 ml-2">
        <div className="relative w-full">
          <SearchOutlined className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Arama yapın..."
            className="pl-10 pr-4 py-2 w-full border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            style={{ borderRadius: '8px' }}
          />
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {/* Notifications */}
        <Badge count={3} className="cursor-pointer">
          <div className="p-2 rounded-lg hover:bg-gray-50 transition-colors duration-200">
            <BellOutlined className="text-gray-600 text-lg" />
          </div>
        </Badge>

        {/* User Menu */}
        <Dropdown menu={{ items: userMenuItems }} trigger={['click']} placement="bottomRight">
          <div className="flex items-center p-2 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors duration-200">
            <Avatar
              icon={<UserOutlined />}
              className="bg-primary-500 text-white mr-3"
            />
            <div className="hidden md:block">
              <p className="text-sm font-medium text-gray-900">
                {user?.full_name || user?.email}
              </p>
              <p className="text-xs text-gray-500 capitalize flex items-center">
                <span className={`inline-block w-2 h-2 rounded-full mr-2 ${user?.role === 'superadmin' ? 'bg-secondary-500' : 'bg-primary-500'}`}></span>
                {user?.role}
              </p>
            </div>
          </div>
        </Dropdown>
      </div>
    </header>
  )
}
