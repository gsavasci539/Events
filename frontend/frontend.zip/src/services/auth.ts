import { http } from './http'

type LoginResponse = { access_token: string; token_type: string }

export const authService = {
  async login(email: string, password: string) {
    const body = new URLSearchParams()
    body.append('username', email)
    body.append('password', password)
    const { data } = await http.post<LoginResponse>('/auth/login', body, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
    // backend does not return user; decode token minimally
    const payload = JSON.parse(atob(data.access_token.split('.')[1]))
    const user = { id: Number(payload.sub), email, role: (payload.role as 'distributor' | 'superadmin') }
    return { ...data, user }
  },
}
