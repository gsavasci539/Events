import { useState, useEffect } from 'react';
import { Card, Tabs, TabsProps, message } from 'antd';
import { UserOutlined, NotificationOutlined, LockOutlined } from '@ant-design/icons';
import { useAuth } from '@/store/auth';
import { NotificationSettingsForm } from '@/components/settings/NotificationSettingsForm';

const SettingsPage = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('notifications');
  const [loading, setLoading] = useState(false);

  if (!user) {
    return null;
  }

  const tabItems: TabsProps['items'] = [
    {
      key: 'notifications',
      label: (
        <span>
          <NotificationOutlined />
          <span>Bildirim Ayarları</span>
        </span>
      ),
      children: <NotificationSettingsForm />,
    },
  ];

  // Add profile tab for all users
  tabItems.unshift({
    key: 'profile',
    label: (
      <span>
        <UserOutlined />
        <span>Profil Bilgileri</span>
      </span>
    ),
    children: (
      <Card title="Profil Bilgileri">
        <div className="space-y-4">
          <div>
            <div className="font-medium text-gray-500">Ad Soyad</div>
            <div>{(user as any)?.full_name || 'Belirtilmemiş'}</div>
          </div>
          <div>
            <div className="font-medium text-gray-500">E-posta</div>
            <div>{user.email}</div>
          </div>
          <div>
            <div className="font-medium text-gray-500">Rol</div>
            <div className="capitalize">{user.role}</div>
          </div>
        </div>
      </Card>
    ),
  });

  // Add password change tab for all users
  tabItems.push({
    key: 'password',
    label: (
      <span>
        <LockOutlined />
        <span>Şifre Değiştir</span>
      </span>
    ),
    children: (
      <Card title="Şifre Değiştir">
        <p>Şifre değiştirme özelliği yakında eklenecektir.</p>
      </Card>
    ),
  });

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Hesap Ayarları</h1>
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        tabPosition="left"
        items={tabItems}
        className="bg-white p-4 rounded-lg shadow"
      />
    </div>
  );
};

export default SettingsPage;
